import {useEffect,useRef,useState} from 'react';
import {motion,AnimatePresence} from 'framer-motion';
import {Heart,MessageCircle,Home,User as UserI,Shield,Search,Image as Img,LogOut,X,Bell,Trash2,Bookmark,Share2,Eye,Plus,Repeat2} from 'lucide-react';

type U={id:number;username:string;avatar:string|null;display?:string;is_admin:number;vs?:string;bio?:string;unread?:number;followers?:number;following?:number;is_following?:number};
type P={id:number;reposts?:number;reposted?:number;rby?:string|null;rdisp?:string|null;rid?:number|null;vs?:string;display?:string;views?:number;saved?:number;user_id:number;username:string;avatar:string|null;body:string;image:string|null;created:number;likes:number;comments:number;liked:number};
type V={t:'home'|'profile'|'search'|'admin'|'notifs'|'saved';v?:string};

async function api(r:string,body?:any,fd?:FormData){
  const h:any={'X-Token':localStorage.getItem('t')||''};let b:any=fd;
  if(body){h['Content-Type']='application/json';b=JSON.stringify(body)}
  const res=await fetch('api/index.php?r='+r,{method:b?'POST':'GET',headers:h,body:b});
  const j=await res.json();if(!res.ok)throw new Error(j.error||'حدث خطأ');return j}
const ago=(t:number)=>{const s=t-Date.now()/1000,f=new Intl.RelativeTimeFormat('ar',{numeric:'auto'});
  return -s<3600?f.format(Math.round(s/60),'minute'):-s<86400?f.format(Math.round(s/3600),'hour'):f.format(Math.round(s/86400),'day')};
const Av=({u,s=44}:{u:{username:string;avatar:string|null};s?:number})=>u.avatar
  ?<img className="av" src={u.avatar} style={{width:s,height:s}}/>
  :<div className="av" style={{width:s,height:s,fontSize:s/2.2,background:`hsl(${[...u.username].reduce((a,c)=>a+c.charCodeAt(0),0)*37%360} 60% 50%)`}}>{u.username[0].toUpperCase()}</div>;

const dn=(u:{display?:string;username:string})=>u.display||u.username;
const Bd=({u}:{u:{vs?:string}})=>u.vs==='verified'?<svg className="vb" viewBox="0 0 24 24" width="16" height="16"><path fill="#1d9bf0" d="M12 1.5l2.6 1.9 3.2-.1 1 3 2.6 1.9-1 3 1 3-2.6 1.9-1 3-3.2-.1L12 22.5l-2.6-1.9-3.2.1-1-3-2.6-1.9 1-3-1-3 2.6-1.9 1-3 3.2.1z"/><path d="m8 12 3 3 5-6" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>:null;
const Rich=({t,open}:{t:string;open:(n:string)=>void})=><>{t.split(/(@\w{3,20})/g).map((s,i)=>s[0]==='@'&&s.length>3?<span key={i} className="mn" onClick={()=>open(s.slice(1))}>{s}</span>:s)}</>;
function MField({v,set,area,onEnter,...p}:{v:string;set:(s:string)=>void;area?:boolean;onEnter?:()=>void;placeholder?:string;rows?:number}){
  const [it,setIt]=useState<any[]>([]),[sel,setSel]=useState(0),[at,setAt]=useState(-1),r=useRef<any>(null);
  const change=(e:any)=>{const x=e.target.value,c=e.target.selectionStart,m=/(^|\s)@(\w*)$/.exec(x.slice(0,c));set(x);
    if(!m){setIt([]);return}setAt(c-m[2].length-1);api('suggest&q='+encodeURIComponent(m[2])).then(l=>{setIt(l);setSel(0)})};
  const pick=(u:any)=>{const c=r.current.selectionStart;set(v.slice(0,at)+'@'+u.username+' '+v.slice(c));setIt([]);setTimeout(()=>{const q=at+u.username.length+2;r.current.focus();r.current.setSelectionRange(q,q)})};
  const key=(e:any)=>{if(it.length){if(e.key==='ArrowDown'){e.preventDefault();setSel((sel+1)%it.length)}else if(e.key==='ArrowUp'){e.preventDefault();setSel((sel+it.length-1)%it.length)}else if(e.key==='Enter'||e.key==='Tab'){e.preventDefault();pick(it[sel])}else if(e.key==='Escape')setIt([])}else if(e.key==='Enter'&&onEnter&&!area)onEnter()};
  const T:any=area?'textarea':'input';
  return <div className="mf"><T ref={r} value={v} onChange={change} onKeyDown={key} {...p}/>
    {!!it.length&&<div className="mdd">{it.map((u,i)=><div key={u.id} className={'mi'+(i===sel?' on':'')} onMouseDown={e=>{e.preventDefault();pick(u)}}><Av u={u} s={28}/><b>@{u.username}</b><Bd u={u}/></div>)}</div>}</div>}

function Auth({done}:{done:()=>void}){
  const [reg,setReg]=useState(false),[u,setU]=useState(''),[p,setP]=useState(''),[e,setE]=useState('');
  const go=async()=>{try{const r=await api(reg?'register':'login',{username:u,password:p});localStorage.setItem('t',r.token);done()}catch(x:any){setE(x.message)}};
  return <div className="auth"><motion.div className="authbox" initial={{opacity:0,y:30,scale:.96}} animate={{opacity:1,y:0,scale:1}}>
    <h1 className="logo">صدى</h1><p style={{textAlign:'center'}}>{reg?'أنشئ حسابك في ثوانٍ':'مرحباً بعودتك'}</p>
    <input placeholder="اسم المستخدم" value={u} dir="ltr" onChange={e=>setU(e.target.value)}/>
    <input type="password" placeholder="كلمة المرور" value={p} dir="ltr" onChange={e=>setP(e.target.value)} onKeyDown={e=>e.key==='Enter'&&go()}/>
    {e&&<div className="err">{e}</div>}
    <button className="btn" onClick={go}>{reg?'إنشاء حساب':'دخول'}</button>
    <a onClick={()=>{setReg(!reg);setE('')}}>{reg?'لديك حساب؟ سجّل الدخول':'ليس لديك حساب؟ أنشئ حساباً'}</a>
  </motion.div></div>}

function Post({p,open,me}:{p:P;open:(n:string)=>void;me:U}){
  const [gone,setGone]=useState(false),[s,setS]=useState(p),[cm,setCm]=useState<any[]|null>(null),[t,setT]=useState('');
  const like=()=>{setS({...s,liked:+!s.liked,likes:s.likes+(s.liked?-1:1)});api('like',{id:s.id})};
  const tog=async()=>setCm(cm?null:await api('comments&id='+s.id));
  const add=async()=>{if(!t.trim())return;await api('comment',{id:s.id,body:t});setT('');setCm(await api('comments&id='+s.id));setS(x=>({...x,comments:x.comments+1}))};
  const del=async()=>{if(confirm('حذف المنشور نهائياً؟')){await api('del',{id:s.id});setGone(true)}};
  const rt=()=>{setS({...s,reposted:+!s.reposted,reposts:(s.reposts||0)+(s.reposted?-1:1)});api('rp',{id:s.id})};
  const bm=()=>{setS({...s,saved:+!s.saved});api('bm',{id:s.id})};
  const share=async()=>{const x=s.body.slice(0,120)+' — @'+s.username;try{if(navigator.share)await navigator.share({text:x,url:location.href});else{await navigator.clipboard.writeText(x+' '+location.href);alert('تم نسخ النص والرابط')}}catch{}};
  if(gone)return null;
  return <motion.article layout initial={{opacity:0,y:16}} animate={{opacity:1,y:0}} className="post">
    <div onClick={()=>open(s.username)}><Av u={s}/></div>
    <div className="pb">{s.rby&&<div className="rtb"><Repeat2 size={14}/>{s.rdisp||s.rby} أعاد النشر</div>}<div className="ph"><b onClick={()=>open(s.username)}>{dn(s)}</b><Bd u={s}/><span className="hd">@{s.username}</span><span>· {ago(s.created)}</span></div>
      <p><Rich t={s.body} open={open}/></p>{s.image&&<img className="pimg" src={s.image} loading="lazy" onClick={()=>window.open(s.image||"","_blank")}/>}
      <div className="acts"><button onClick={tog}><MessageCircle size={18}/>{s.comments}</button>
        <button className={s.reposted?'rt on':'rt'} onClick={rt}><Repeat2 size={18}/>{s.reposts||0}</button>
        <motion.button whileTap={{scale:1.4}} className={s.liked?'liked':''} onClick={like}><Heart size={18} fill={s.liked?'currentColor':'none'}/>{s.likes}</motion.button>
        <span className="vw"><Eye size={18}/>{s.views||0}</span>
        <button className={s.saved?'saved':''} onClick={bm}><Bookmark size={18} fill={s.saved?'currentColor':'none'}/></button>
        <button onClick={share}><Share2 size={18}/></button>
        {(me.id===s.user_id||!!me.is_admin)&&<button className="del" onClick={del}><Trash2 size={18}/></button>}</div>
      <AnimatePresence>{cm&&<motion.div className="cms" initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}}>
        {cm.map(c=><div key={c.id} className="cm"><Av u={c} s={28}/><div><b>{dn(c)}</b><Bd u={c}/> <small>@{c.username} · {ago(c.created)}</small><div><Rich t={c.body} open={open}/></div></div></div>)}
        <div style={{display:'flex',gap:8,marginTop:8}}><MField placeholder="اكتب تعليقاً" v={t} set={setT} onEnter={add}/><button className="btn sm" onClick={add}>إرسال</button></div>
      </motion.div>}</AnimatePresence></div></motion.article>}

function Composer({me,max,add}:{me:U;max:number;add:(p:P)=>void}){
  const [b,setB]=useState(''),[f,setF]=useState<File|null>(null),[e,setE]=useState(''),ref=useRef<HTMLInputElement>(null),left=max-b.length;
  const send=async()=>{const fd=new FormData();fd.append('body',b);f&&fd.append('image',f);
    try{add(await api('post',undefined,fd));setB('');setF(null);setE('')}catch(x:any){setE(x.message)}};
  return <div className="post comp"><Av u={me}/><div className="pb">
    <MField area placeholder="ماذا يحدث؟" rows={2} v={b} set={setB}/>
    {f&&<div className="prev"><img src={URL.createObjectURL(f)}/><button onClick={()=>setF(null)}><X size={16}/></button></div>}
    {e&&<div className="err">{e}</div>}
    <div className="cbar"><button onClick={()=>ref.current?.click()}><Img size={20}/></button>
      <input ref={ref} hidden type="file" accept="image/*" onChange={e=>setF(e.target.files?.[0]||null)}/>
      <span className={left<0?'over':left<20?'warn':''}>{left}</span>
      <button className="btn sm" disabled={left<0||(!b.trim()&&!f)} onClick={send}>نشر</button></div></div></div>}

function Feed({me,max,user,open,composer,tab,tick}:{me:U;max:number;user?:number;open:(n:string)=>void;composer?:boolean;tab?:string;tick?:number}){
  const [ps,setPs]=useState<P[]|null>(null);
  useEffect(()=>{setPs(null);api('feed&u='+(user||0)+'&f='+(tab==='fol'?1:0)).then(setPs)},[user,tab,tick]);
  return <>{composer&&<Composer me={me} max={max} add={p=>setPs(x=>[p,...(x||[])])}/>}
    {ps===null?<div className="empty">جارٍ التحميل…</div>:ps.length?ps.map(p=><Post key={p.id+'-'+(p.rid||0)} p={p} open={open} me={me}/>):<div className="empty">لا منشورات بعد. انشر أول منشور أو تابع أشخاصاً.</div>}</>}

function Profile({name,me,max,open,reload}:{name:string;me:U;max:number;open:(n:string)=>void;reload:()=>void}){
  const [u,setU]=useState<U|null>(null),[ed,setEd]=useState(false),[bio,setBio]=useState(''),[dnm,setDnm]=useState(''),ref=useRef<HTMLInputElement>(null);
  const load=()=>api('user&name='+encodeURIComponent(name)).then(setU);
  useEffect(()=>{load()},[name]);
  if(!u)return <div className="empty">جارٍ التحميل…</div>;
  const own=u.id===me.id;
  const saveBio=async()=>{await api('display',{display:dnm});await api('bio',{bio});setEd(false);load();reload()};
  const pic=async(f?:File)=>{if(!f)return;const fd=new FormData();fd.append('avatar',f);await api('avatar',undefined,fd);load();reload()};
  return <><div className="cover"/><div className="pinfo">
    <div className={own?'avw own':'avw'} title={own?'تغيير الصورة':''} onClick={()=>own&&ref.current?.click()}><Av u={u} s={88}/></div>
    <input ref={ref} hidden type="file" accept="image/*" onChange={e=>pic(e.target.files?.[0])}/>
    {!own&&<button className={'btn sm '+(u.is_following?'ghost':'')} onClick={async()=>{await api('follow',{id:u.id});load()}}>{u.is_following?'إلغاء المتابعة':'متابعة'}</button>}
    <h2>{dn(u)}<Bd u={u}/>{u.is_admin?<Shield size={16}/>:null}</h2><small>@{u.username}</small>
    {ed?<div className="bioedit"><input value={dnm} maxLength={30} placeholder="الاسم المعروض" onChange={e=>setDnm(e.target.value)}/><input value={bio} maxLength={160} placeholder="نبذة عنك" onChange={e=>setBio(e.target.value)}/><button className="btn sm" onClick={saveBio}>حفظ</button></div>
      :<p className="bio">{u.bio||(own?'أضف نبذة عن نفسك':'')}{own&&<button onClick={()=>{setBio(u.bio||'');setDnm(u.display||'');setEd(true)}}>تعديل</button>}</p>}
    {own&&u.vs!=='verified'&&<div style={{margin:'8px 0'}}>{u.vs==='pending'?<small>طلب التوثيق قيد المراجعة</small>:<button className="btn sm ghost" onClick={async()=>{await api('vreq',{});load()}}>{u.vs==='rejected'?'رُفض طلبك — قدّم مجدداً':'طلب التوثيق'}</button>}</div>}
    <div className="stats"><span><b>{u.following}</b> يتابع</span><span><b>{u.followers}</b> متابِع</span></div></div>
    <Feed me={me} max={max} user={u.id} open={open}/></>}

function Found({q,open,me}:{q:string;open:(n:string)=>void;me:U}){
  const [r,setR]=useState<any>(null);
  useEffect(()=>{api('search&q='+encodeURIComponent(q)).then(setR)},[q]);
  if(!r)return <div className="empty">جارٍ البحث…</div>;
  return <>{r.users.map((u:U)=><div key={u.id} className="post urow" onClick={()=>open(u.username)}><Av u={u}/><div><b>{dn(u)}</b><Bd u={u}/><small style={{display:'block'}}>@{u.username}</small></div></div>)}
    {r.posts.map((p:P)=><Post key={p.id} p={p} open={open} me={me}/>)}
    {!r.users.length&&!r.posts.length&&<div className="empty">لا نتائج لـ «{q}»</div>}</>}

function Notifs({open,clear}:{open:(n:string)=>void;clear:()=>void}){
  const [l,setL]=useState<any[]|null>(null),t:any={like:'أعجب بمنشورك',comment:'علّق على منشورك',follow:'بدأ بمتابعتك',mention:'أشار إليك',repost:'أعاد نشر منشورك',vreq:'قدّم طلب توثيق',verified:'وافق على طلب توثيقك ✓',rejected:'رفض طلب توثيقك',revoked:'ألغى توثيق حسابك'};
  useEffect(()=>{api('notifs').then(setL);api('seen',{}).then(clear)},[]);
  if(!l)return <div className="empty">جارٍ التحميل…</div>;
  return <>{l.map(n=><div key={n.id} className={'post urow'+(n.seen?'':' new')} onClick={()=>open(n.username)}><Av u={n}/><div><b>{dn(n)}</b><Bd u={n}/> {t[n.type]}{n.snip&&<small>{n.snip}</small>}<small>{ago(n.created)}</small></div></div>)}
    {!l.length&&<div className="empty">لا إشعارات بعد</div>}</>}

function Saved({open,me}:{open:(n:string)=>void;me:U}){
  const [l,setL]=useState<P[]|null>(null);useEffect(()=>{api('saved').then(setL)},[]);
  return l===null?<div className="empty">جارٍ التحميل…</div>:l.length?<>{l.map(p=><Post key={p.id} p={p} open={open} me={me}/>)}</>:<div className="empty">لا منشورات محفوظة بعد</div>}

function Admin({max,setMax,me}:{max:number;setMax:(n:number)=>void;me:U}){
  const [v,setV]=useState(max),[ok,setOk]=useState(false),[rq,setRq]=useState<any[]>([]),[us,setUs]=useState<any[]>([]),[uf,setUf]=useState('');
  useEffect(()=>{api('vlist').then(setRq);api('admin_users').then(setUs)},[]);
  const dec=async(id:number,yes:boolean)=>{await api('vset',{id,ok:yes});setRq(x=>x.filter(u=>u.id!==id));api('admin_users').then(setUs)};
  const act=async(id:number,a:string)=>{if(a==='udel'&&!confirm('حذف المستخدم وكل محتواه نهائياً؟'))return;await api('uact',{id,act:a});api('admin_users').then(setUs);api('vlist').then(setRq)};
  const Row=({u,children}:{u:any;children:any})=><div className="ur"><Av u={u} s={32}/><div className="ui"><b>@{u.username}</b><Bd u={u}/>{Number(u.is_admin)?' 🛡️':''}{Number(u.ban)?<small> (موقوف)</small>:null}<small>{u.posts} منشور، {u.followers} متابِع</small></div><div className="ua">{children}</div></div>;
  const B=({u,a,l,c=''}:{u:any;a:string;l:string;c?:string})=><button className={'btn sm ghost '+c} onClick={()=>act(u.id,a)}>{l}</button>;
  return <div className="panel"><h3>لوحة الإدارة</h3><b>طلبات التوثيق</b>{rq.length?rq.map(u=><div key={u.id} className="rq"><Av u={u} s={32}/><b>@{u.username}</b><button className="btn sm" onClick={()=>dec(u.id,true)}>موافقة</button><button className="btn sm ghost" onClick={()=>dec(u.id,false)}>رفض</button></div>):<small>لا طلبات معلّقة</small>}<hr/>
    <b>الحسابات الموثّقة ({us.filter(u=>u.vs==='verified').length})</b>{us.filter(u=>u.vs==='verified').map(u=><Row key={u.id} u={u}><B u={u} a="vrev" l="إلغاء التوثيق"/></Row>)}<hr/>
    <b>إدارة المستخدمين ({us.length})</b><input placeholder="ابحث باسم المستخدم" value={uf} onChange={e=>setUf(e.target.value)}/>
    {us.filter(u=>u.username.toLowerCase().includes(uf.toLowerCase())).map(u=><Row key={u.id} u={u}>{u.id===me.id?<small>أنت</small>:<>
      <B u={u} a={u.vs==='verified'?'vrev':'vgive'} l={u.vs==='verified'?'إلغاء التوثيق':'توثيق'}/>
      <B u={u} a="adm" l={Number(u.is_admin)?'إزالة الإدارة':'ترقية لمدير'}/>
      {!Number(u.is_admin)&&<><B u={u} a="ban" l={Number(u.ban)?'رفع الحظر':'حظر'}/><B u={u} a="udel" l="حذف" c="red"/></>}</>}</Row>)}<hr/><label>الحد الأقصى لأحرف المنشور</label>
    <input type="number" min={1} value={v} onChange={e=>{setV(+e.target.value);setOk(false)}}/>
    <button className="btn" onClick={async()=>{await api('set_max',{max_chars:v});setMax(v);setOk(true)}}>حفظ</button>{ok&&<span className="ok">تم الحفظ</span>}</div>}

export default function App(){
  const [me,setMe]=useState<U|null>(null),[ready,setReady]=useState(false),[v,setV]=useState<V>({t:'home'}),[max,setMax]=useState(280),[q,setQ]=useState(''),[un,setUn]=useState(0),[tab,setTab]=useState('all'),[tick,setTick]=useState(0),[comp,setComp]=useState(false);
  const boot=()=>api('me').then(u=>{setMe(u);setUn(u.unread||0);return api('settings')}).then(s=>setMax(s.max_chars)).catch(()=>setMe(null)).finally(()=>setReady(true));
  useEffect(()=>{boot()},[]);
  useEffect(()=>{if(!me)return;const i=setInterval(()=>api('me').then(u=>setUn(u.unread||0)),30000);return()=>clearInterval(i)},[me?.id]);
  if(!ready)return null;if(!me)return <Auth done={boot}/>;
  const open=(n:string)=>setV({t:'profile',v:n});
  const nav:{t:V['t'];l:string;i:JSX.Element;v?:string}[]=[{t:'home',l:'الرئيسية',i:<Home/>},{t:'notifs',l:'الإشعارات',i:<span className="bw"><Bell/>{un>0&&<i className="dot">{un}</i>}</span>},{t:'profile',l:'ملفي',i:<UserI/>,v:me.username},{t:'saved',l:'المحفوظات',i:<Bookmark/>},...(me.is_admin?[{t:'admin' as const,l:'الإدارة',i:<Shield/>}]:[])];
  return <div className="app"><aside><h1 className="logo">صدى</h1>
    {nav.map(n=><button key={n.t} className={v.t===n.t&&(n.t!=='profile'||v.v===me.username)?'on':''} onClick={()=>setV({t:n.t,v:n.v})}>{n.i}<span>{n.l}</span></button>)}
    <button onClick={()=>{localStorage.removeItem('t');setMe(null)}}><LogOut/><span>خروج</span></button></aside>
    <main><header><span className="mav" onClick={()=>open(me.username)}><Av u={me} s={32}/></span><Search size={18}/><input placeholder="ابحث عن أشخاص أو منشورات" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&q.trim()&&setV({t:'search',v:q})}/></header>
      {v.t==='home'&&<div className="tabs"><button className={tab==='all'?'on':''} onClick={()=>setTab('all')}>لك</button><button className={tab==='fol'?'on':''} onClick={()=>setTab('fol')}>متابعة</button></div>}
      <AnimatePresence mode="wait"><motion.div className="view" key={v.t+(v.v||'')} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:.18}}>
        {v.t==='home'&&<Feed key={tab} me={me} max={max} open={open} tab={tab} tick={tick} composer/>}
        {v.t==='saved'&&<Saved open={open} me={me}/>}
        {v.t==='profile'&&<Profile name={v.v!} me={me} max={max} open={open} reload={boot}/>}
        {v.t==='search'&&<Found q={v.v!} open={open} me={me}/>}
        {v.t==='notifs'&&<Notifs open={open} clear={()=>setUn(0)}/>}
        {v.t==='admin'&&<Admin max={max} setMax={setMax} me={me}/>}
      </motion.div></AnimatePresence></main>
    <button className="fab" onClick={()=>setComp(true)}><Plus/></button>
    <AnimatePresence>{comp&&<motion.div className="modal" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setComp(false)}>
      <motion.div className="mbox" initial={{y:40}} animate={{y:0}} onClick={e=>e.stopPropagation()}><button className="mx" onClick={()=>setComp(false)}><X/></button>
        <Composer me={me} max={max} add={()=>{setComp(false);setV({t:'home'});setTab('all');setTick(t=>t+1)}}/></motion.div></motion.div>}</AnimatePresence></div>}
