<?php
header('Content-Type: application/json; charset=utf-8');
$d=__DIR__;@mkdir("$d/uploads");
$db=new PDO("sqlite:$d/data.db");$db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,pass TEXT,display TEXT DEFAULT '',avatar TEXT,bio TEXT DEFAULT '',is_admin INT DEFAULT 0,vs TEXT DEFAULT '',ban INT DEFAULT 0,token TEXT,created INT);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY,user_id INT,body TEXT,image TEXT,views INT DEFAULT 0,hidden INT DEFAULT 0,created INT);
CREATE TABLE IF NOT EXISTS likes(user_id INT,post_id INT,PRIMARY KEY(user_id,post_id));
CREATE TABLE IF NOT EXISTS reposts(user_id INT,post_id INT,created INT,PRIMARY KEY(user_id,post_id));
CREATE TABLE IF NOT EXISTS bookmarks(user_id INT,post_id INT,PRIMARY KEY(user_id,post_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY,user_id INT,post_id INT,body TEXT,hidden INT DEFAULT 0,created INT);
CREATE TABLE IF NOT EXISTS follows(follower INT,followed INT,PRIMARY KEY(follower,followed));
CREATE TABLE IF NOT EXISTS notifs(id INTEGER PRIMARY KEY,user_id INT,actor INT,type TEXT,post_id INT DEFAULT 0,created INT,seen INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE INDEX IF NOT EXISTS i1 ON posts(user_id);CREATE INDEX IF NOT EXISTS i2 ON follows(followed);CREATE INDEX IF NOT EXISTS i3 ON notifs(user_id);CREATE INDEX IF NOT EXISTS i4 ON users(token);
INSERT OR IGNORE INTO settings VALUES('max_chars','280');");
foreach(["ALTER TABLE posts ADD COLUMN hidden INT DEFAULT 0","ALTER TABLE comments ADD COLUMN hidden INT DEFAULT 0","CREATE TABLE IF NOT EXISTS views(post_id INT,viewer TEXT,PRIMARY KEY(post_id,viewer))"] as $s)try{$db->exec($s);}catch(Exception $e){}
function q($s,$a=[]){global $db;$t=$db->prepare($s);$t->execute($a);return $t;}
function out($x,$c=200){http_response_code($c);echo json_encode($x,JSON_UNESCAPED_UNICODE);exit;}
function err($m,$c=400){out(['error'=>$m],$c);}
$in=json_decode(file_get_contents('php://input'),true)?:$_POST;
$r=$_GET['r']??'';$tok=$_SERVER['HTTP_X_TOKEN']??'';
$me=$tok?q("SELECT id,username,avatar,bio,is_admin,vs,display FROM users WHERE token=? AND ban=0",[$tok])->fetch(PDO::FETCH_ASSOC):null;
function need(){global $me;if(!$me)err('سجّل الدخول أولاً',401);return $me;}
function notify($to,$type,$post=0){global $me;if($to&&$to!=$me['id'])q("INSERT INTO notifs(user_id,actor,type,post_id,created) VALUES(?,?,?,?,?)",[$to,$me['id'],$type,$post,time()]);}
function mentions($t,$pid){preg_match_all('/@(\w{3,20})/',$t,$m);foreach(array_unique($m[1]) as $n){$i=q("SELECT id FROM users WHERE username=?",[$n])->fetchColumn();if($i)notify($i,'mention',$pid);}}
function seen($id,$v){if(q("INSERT OR IGNORE INTO views VALUES(?,?)",[$id,$v])->rowCount())q("UPDATE posts SET views=views+1 WHERE id=?",[$id]);}
function maxc(){return (int)q("SELECT v FROM settings WHERE k='max_chars'")->fetchColumn();}
function up($k){
 if(empty($_FILES[$k])||$_FILES[$k]['error'])return null;
 $i=@getimagesize($_FILES[$k]['tmp_name']);
 $e=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'][$i['mime']??'']??null;
 if(!$e)err('ملف الصورة غير صالح');if($_FILES[$k]['size']>5e6)err('الصورة أكبر من 5MB');
 $n=bin2hex(random_bytes(8)).".$e";move_uploaded_file($_FILES[$k]['tmp_name'],__DIR__."/uploads/$n");return "api/uploads/$n";}
function rposts($w,$a,$uid){return q("SELECT p.*,u.username,u.avatar,u.vs,u.display,(SELECT COUNT(*) FROM likes WHERE post_id=p.id) likes,(SELECT COUNT(*) FROM comments WHERE post_id=p.id AND hidden=0) comments,EXISTS(SELECT 1 FROM likes WHERE post_id=p.id AND user_id=?) liked,EXISTS(SELECT 1 FROM bookmarks WHERE post_id=p.id AND user_id=?) saved,(SELECT COUNT(*) FROM reposts WHERE post_id=p.id) reposts,EXISTS(SELECT 1 FROM reposts WHERE post_id=p.id AND user_id=?) reposted,ru.username rby,ru.display rdisp,rp.user_id rid,rp.created at FROM reposts rp JOIN posts p ON p.id=rp.post_id JOIN users u ON u.id=p.user_id JOIN users ru ON ru.id=rp.user_id WHERE p.hidden=0 AND ($w)",array_merge([$uid,$uid,$uid],$a))->fetchAll(PDO::FETCH_ASSOC);}
function feedmix($a,$b,$uid){$f=q("SELECT followed FROM follows WHERE follower=?",[$uid])->fetchAll(PDO::FETCH_COLUMN);$f[]=$uid;
 $k=fn($x)=>(in_array($x['user_id'],$f)||($x['rid']&&in_array($x['rid'],$f)))?1:0;
 $l=array_merge($a,$b);usort($l,fn($x,$y)=>[$k($y),$y['at']]<=>[$k($x),$x['at']]);return array_slice($l,0,100);}
function posts($w,$a,$uid){return q("SELECT p.*,u.username,u.avatar,u.vs,u.display,(SELECT COUNT(*) FROM likes WHERE post_id=p.id) likes,(SELECT COUNT(*) FROM comments WHERE post_id=p.id AND hidden=0) comments,EXISTS(SELECT 1 FROM likes WHERE post_id=p.id AND user_id=?) liked,EXISTS(SELECT 1 FROM bookmarks WHERE post_id=p.id AND user_id=?) saved,(SELECT COUNT(*) FROM reposts WHERE post_id=p.id) reposts,EXISTS(SELECT 1 FROM reposts WHERE post_id=p.id AND user_id=?) reposted,NULL rby,NULL rdisp,NULL rid,p.created at FROM posts p JOIN users u ON u.id=p.user_id WHERE p.hidden=0 AND ($w) ORDER BY (p.user_id=? OR p.user_id IN (SELECT followed FROM follows WHERE follower=?)) DESC,p.created DESC LIMIT 100",array_merge([$uid,$uid,$uid],$a,[$uid,$uid]))->fetchAll(PDO::FETCH_ASSOC);}
switch($r){
case 'register':case 'login':
 $u=trim($in['username']??'');$p=$in['password']??'';
 if($r=='register'){
  if(!preg_match('/^\w{3,20}$/',$u)||strlen($p)<6)err('اسم المستخدم 3-20 (حروف إنجليزية وأرقام و _) وكلمة المرور 6 أحرف على الأقل');
  if(q("SELECT 1 FROM users WHERE username=?",[$u])->fetch())err('اسم المستخدم محجوز');
  $ad=q("SELECT COUNT(*) FROM users")->fetchColumn()==0?1:0;q("INSERT INTO users(username,pass,is_admin,vs,created) VALUES(?,?,?,?,?)",[$u,password_hash($p,PASSWORD_DEFAULT),$ad,$ad?'verified':'',time()]);
 }
 $row=q("SELECT * FROM users WHERE username=?",[$u])->fetch(PDO::FETCH_ASSOC);
 if(!$row||!password_verify($p,$row['pass']))err('بيانات الدخول غير صحيحة',401);if($row['ban'])err('هذا الحساب موقوف',403);
 $t=bin2hex(random_bytes(24));q("UPDATE users SET token=? WHERE id=?",[$t,$row['id']]);out(['token'=>$t]);
case 'me':out(need()+['unread'=>(int)q("SELECT COUNT(*) FROM notifs WHERE user_id=? AND seen=0",[$me['id']])->fetchColumn()]);
case 'settings':out(['max_chars'=>maxc()]);
case 'set_max':if(!need()['is_admin'])err('غير مسموح',403);q("REPLACE INTO settings VALUES('max_chars',?)",[max(1,(int)($in['max_chars']??280))]);out(['ok'=>1]);
case 'feed':
 $m=need();$u=(int)($_GET['u']??0);
 $i=$m['id'];
 if($u)$l=feedmix(posts("p.user_id=?",[$u],$i),rposts("rp.user_id=?",[$u],$i),$i);
 elseif(!empty($_GET['f']))$l=feedmix(posts("(p.user_id=? OR p.user_id IN (SELECT followed FROM follows WHERE follower=?))",[$i,$i],$i),rposts("(rp.user_id=? OR rp.user_id IN (SELECT followed FROM follows WHERE follower=?))",[$i,$i],$i),$i);
 else $l=feedmix(posts("1",[],$i),rposts("1",[],$i),$i);
 foreach($l as $x)if($x['user_id']!=$m['id'])seen((int)$x['id'],'u'.$m['id']);
 out($l);
case 'post':
 $m=need();$b=trim($in['body']??'');$img=up('image');
 if($b===''&&!$img)err('اكتب شيئاً أو أضف صورة');if(mb_strlen($b)>maxc())err('تجاوزت الحد الأقصى للأحرف');
 q("INSERT INTO posts(user_id,body,image,created) VALUES(?,?,?,?)",[$m['id'],$b,$img,time()]);
 $id=$db->lastInsertId();mentions($b,$id);out(posts("p.id=?",[$id],$m['id'])[0]);
case 'like':$m=need();$id=(int)$in['id'];if(q("DELETE FROM likes WHERE user_id=? AND post_id=?",[$m['id'],$id])->rowCount()==0){q("INSERT INTO likes VALUES(?,?)",[$m['id'],$id]);notify((int)q("SELECT user_id FROM posts WHERE id=?",[$id])->fetchColumn(),'like',$id);}out(['ok'=>1]);
case 'comments':out(q("SELECT c.id,c.body,c.created,u.username,u.avatar,u.vs,u.display FROM comments c JOIN users u ON u.id=c.user_id WHERE post_id=? AND c.hidden=0 ORDER BY c.id",[(int)$_GET['id']])->fetchAll(PDO::FETCH_ASSOC));
case 'comment':$m=need();$b=trim($in['body']??'');if($b===''||mb_strlen($b)>maxc())err('تعليق غير صالح');q("INSERT INTO comments(user_id,post_id,body,created) VALUES(?,?,?,?)",[$m['id'],(int)$in['id'],$b,time()]);notify((int)q("SELECT user_id FROM posts WHERE id=?",[(int)$in['id']])->fetchColumn(),'comment',(int)$in['id']);mentions($b,(int)$in['id']);out(['ok'=>1]);
case 'user':
 $m=need();$x=q("SELECT id,username,avatar,bio,is_admin,vs,display,(SELECT COUNT(*) FROM follows WHERE followed=users.id) followers,(SELECT COUNT(*) FROM follows WHERE follower=users.id) following,EXISTS(SELECT 1 FROM follows WHERE follower=? AND followed=users.id) is_following FROM users WHERE username=?",[$m['id'],$_GET['name']??''])->fetch(PDO::FETCH_ASSOC);
 $x?out($x):err('المستخدم غير موجود',404);
case 'follow':$m=need();$id=(int)$in['id'];if($id==$m['id'])err('لا يمكنك متابعة نفسك');if(q("DELETE FROM follows WHERE follower=? AND followed=?",[$m['id'],$id])->rowCount()==0){q("INSERT INTO follows VALUES(?,?)",[$m['id'],$id]);notify($id,'follow');}out(['ok'=>1]);
case 'avatar':$m=need();$a=up('avatar');if(!$a)err('اختر صورة');q("UPDATE users SET avatar=? WHERE id=?",[$a,$m['id']]);out(['avatar'=>$a]);
case 'search':$m=need();$s='%'.str_replace(['%','_'],'',$_GET['q']??'').'%';out(['users'=>q("SELECT id,username,avatar,vs,display FROM users WHERE username LIKE ? OR display LIKE ? LIMIT 20",[$s,$s])->fetchAll(PDO::FETCH_ASSOC),'posts'=>posts("p.body LIKE ?",[$s],$m['id'])]);
case 'bio':$m=need();q("UPDATE users SET bio=? WHERE id=?",[mb_substr(trim($in['bio']??''),0,160),$m['id']]);out(['ok'=>1]);
case 'del':$m=need();$id=(int)$in['id'];$o=(int)q("SELECT user_id FROM posts WHERE id=?",[$id])->fetchColumn();if(!$o||($o!=$m['id']&&!$m['is_admin']))err('غير مسموح',403);foreach(['likes','comments','notifs','bookmarks','reposts','views'] as $t)q("DELETE FROM $t WHERE post_id=?",[$id]);q("DELETE FROM posts WHERE id=?",[$id]);out(['ok'=>1]);
case 'notifs':$m=need();out(q("SELECT n.id,n.type,n.post_id,n.created,n.seen,u.username,u.avatar,u.vs,u.display,substr(p.body,1,60) snip FROM notifs n JOIN users u ON u.id=n.actor LEFT JOIN posts p ON p.id=n.post_id WHERE n.user_id=? ORDER BY n.id DESC LIMIT 50",[$m['id']])->fetchAll(PDO::FETCH_ASSOC));
case 'seen':$m=need();q("UPDATE notifs SET seen=1 WHERE user_id=?",[$m['id']]);out(['ok'=>1]);
case 'suggest':need();$s=str_replace(['%','_'],'',$_GET['q']??'');out(q("SELECT id,username,avatar,vs,display FROM users WHERE username LIKE ? ORDER BY (username LIKE ?) DESC,(vs='verified') DESC,username LIMIT 5",['%'.$s.'%',$s.'%'])->fetchAll(PDO::FETCH_ASSOC));
case 'vreq':$m=need();if($m['vs']=='verified')err('حسابك موثّق');q("UPDATE users SET vs='pending' WHERE id=?",[$m['id']]);foreach(q("SELECT id FROM users WHERE is_admin=1")->fetchAll(PDO::FETCH_COLUMN) as $a)notify($a,'vreq');out(['ok'=>1]);
case 'vlist':if(!need()['is_admin'])err('غير مسموح',403);out(q("SELECT id,username,avatar,vs FROM users WHERE vs='pending'")->fetchAll(PDO::FETCH_ASSOC));
case 'vset':if(!need()['is_admin'])err('غير مسموح',403);$ok=!empty($in['ok']);q("UPDATE users SET vs=? WHERE id=?",[$ok?'verified':'rejected',(int)$in['id']]);notify((int)$in['id'],$ok?'verified':'rejected');out(['ok'=>1]);
case 'admin_users':if(!need()['is_admin'])err('غير مسموح',403);out(q("SELECT id,username,avatar,is_admin,vs,ban,(SELECT COUNT(*) FROM posts WHERE user_id=users.id) posts,(SELECT COUNT(*) FROM follows WHERE followed=users.id) followers FROM users ORDER BY id")->fetchAll(PDO::FETCH_ASSOC));
case 'uact':
 $m=need();if(!$m['is_admin'])err('غير مسموح',403);$id=(int)($in['id']??0);$act=$in['act']??'';
 $t=q("SELECT * FROM users WHERE id=?",[$id])->fetch(PDO::FETCH_ASSOC);if(!$t||$id==$m['id'])err('غير مسموح');
 if(in_array($act,['ban','udel'])&&$t['is_admin'])err('لا يمكن تنفيذ ذلك على مدير');
 if($act=='vrev'||$act=='vgive'){q("UPDATE users SET vs=? WHERE id=?",[$act=='vgive'?'verified':'',$id]);notify($id,$act=='vgive'?'verified':'revoked');}
 elseif($act=='adm')q("UPDATE users SET is_admin=1-is_admin WHERE id=?",[$id]);
 elseif($act=='ban')q("UPDATE users SET ban=1-ban,token=NULL WHERE id=?",[$id]);
 elseif($act=='udel'){$pp="post_id IN (SELECT id FROM posts WHERE user_id=?)";q("DELETE FROM likes WHERE user_id=? OR $pp",[$id,$id]);q("DELETE FROM comments WHERE user_id=? OR $pp",[$id,$id]);q("DELETE FROM notifs WHERE user_id=? OR actor=? OR $pp",[$id,$id,$id]);q("DELETE FROM follows WHERE follower=? OR followed=?",[$id,$id]);q("DELETE FROM posts WHERE user_id=?",[$id]);q("DELETE FROM users WHERE id=?",[$id]);}
 else err('إجراء غير معروف');
 out(['ok'=>1]);
case 'rp':$m=need();$id=(int)$in['id'];if(q("DELETE FROM reposts WHERE user_id=? AND post_id=?",[$m['id'],$id])->rowCount()==0){q("INSERT INTO reposts VALUES(?,?,?)",[$m['id'],$id,time()]);notify((int)q("SELECT user_id FROM posts WHERE id=?",[$id])->fetchColumn(),'repost',$id);}out(['ok'=>1]);
case 'one':
 $uid=$me['id']??0;$p=posts("p.id=?",[(int)($_GET['id']??0)],$uid)[0]??null;if(!$p)err('المنشور غير موجود',404);
 if($p['user_id']!=$uid)seen((int)$p['id'],$uid?'u'.$uid:'g'.substr(sha1(($_SERVER['REMOTE_ADDR']??'').($_SERVER['HTTP_USER_AGENT']??'')),0,16));out($p);
case 'flist':$m=need();$t=($_GET['t']??'')=='following';
 out(q("SELECT u.id,u.username,u.avatar,u.vs,u.display,EXISTS(SELECT 1 FROM follows WHERE follower=? AND followed=u.id) is_following FROM follows f JOIN users u ON u.id=".($t?'f.followed':'f.follower')." WHERE ".($t?'f.follower':'f.followed')."=(SELECT id FROM users WHERE username=?) AND u.ban=0 ORDER BY u.username",[$m['id'],$_GET['name']??''])->fetchAll(PDO::FETCH_ASSOC));
case 'admin_user':
 if(!need()['is_admin'])err('غير مسموح',403);$id=(int)($_GET['id']??0);
 out(['stats'=>q("SELECT (SELECT COUNT(*) FROM posts WHERE user_id=?) posts,(SELECT COUNT(*) FROM comments WHERE user_id=?) comments,(SELECT COUNT(*) FROM likes WHERE post_id IN (SELECT id FROM posts WHERE user_id=?)) likes,(SELECT COALESCE(SUM(views),0) FROM posts WHERE user_id=?) views,(SELECT COUNT(*) FROM follows WHERE followed=?) followers,(SELECT COUNT(*) FROM follows WHERE follower=?) following",[$id,$id,$id,$id,$id,$id])->fetch(PDO::FETCH_ASSOC),
 'posts'=>q("SELECT id,body,image,hidden,created FROM posts WHERE user_id=? ORDER BY id DESC LIMIT 100",[$id])->fetchAll(PDO::FETCH_ASSOC),
 'comments'=>q("SELECT id,body,hidden,created FROM comments WHERE user_id=? ORDER BY id DESC LIMIT 100",[$id])->fetchAll(PDO::FETCH_ASSOC)]);
case 'admin_content':
 if(!need()['is_admin'])err('غير مسموح',403);$id=(int)($in['id']??0);$tb=($in['kind']??'')=='comment'?'comments':'posts';$act=$in['act']??'';
 if($act=='edit')q("UPDATE $tb SET body=? WHERE id=?",[mb_substr(trim($in['body']??''),0,2000),$id]);
 elseif($act=='hide')q("UPDATE $tb SET hidden=1-hidden WHERE id=?",[$id]);
 elseif($act=='del'){if($tb=='posts')foreach(['likes','comments','notifs','bookmarks','reposts','views'] as $t)q("DELETE FROM $t WHERE post_id=?",[$id]);q("DELETE FROM $tb WHERE id=?",[$id]);}
 else err('إجراء غير معروف');
 out(['ok'=>1]);
case 'display':$m=need();q("UPDATE users SET display=? WHERE id=?",[mb_substr(trim($in['display']??''),0,30),$m['id']]);out(['ok'=>1]);
case 'bm':$m=need();$id=(int)$in['id'];if(q("DELETE FROM bookmarks WHERE user_id=? AND post_id=?",[$m['id'],$id])->rowCount()==0)q("INSERT INTO bookmarks VALUES(?,?)",[$m['id'],$id]);out(['ok'=>1]);
case 'saved':$m=need();out(posts("p.id IN (SELECT post_id FROM bookmarks WHERE user_id=?)",[$m['id']],$m['id']));
default:err('غير موجود',404);}
